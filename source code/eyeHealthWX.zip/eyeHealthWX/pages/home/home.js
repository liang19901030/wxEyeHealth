// pages/home/home.js
import util from '../../utils/util.js'
import config from '../../utils/config.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    defaultSize: 'default',
    userName: '', // 用户姓名
    userTeleno: '', // 用户手机号
    userAvater: '', // 用户头像
    avatarUrl: '', //微信用户头像
  },
  viewInfo: function() {
    wx.navigateTo({
      url: '../info/info',
    })

  },
  myOrder: function() {
    wx.navigateTo({
      url: '../myOrder/myOrder',
    })
  },
  myFamily: function() {
    wx.navigateTo({
      url: '../family/family?type=0',
    })
  },
  viewReport: function() {
    wx.navigateTo({
      url: '../report/report',
    })
  },
  order: function() {
    wx.navigateTo({
      url: '../order/order',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // var openId = (wx.getStorageSync('openid'))
    // if (!openId) {
    //   wx.getUserInfo({
    //     success: function(res) {
    //       that.setData({
    //         avatarUrl: res.userInfo.avatarUrl,
    //       })
    //     },
    //     fail: function() {
    //       // fail
    //       console.log("获取失败！")
    //     },
    //     complete: function() {
    //       // complete
    //       console.log("获取用户信息完成！")
    //     }
    //   })
    // } else {
      wx.login({
        success: function(res) {
          if (res.code) {
            console.log('获取用户登录成功！' + res.code)
            wx.request({
              url: config.server.api + 'patients/loginByMiniProgram',
              method: 'POST',
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              data: {
                code: res.code
              },
              success: function(res) {
                if (res.data.responseCode == 0) {
                  wx.setStorageSync('terryUser', res.data.returnObject)
                  // wx.navigateTo({
                  //   url: '../home/home'
                  // })
                } else if (res.data.responseCode == 80014) {
                  //小程序第一次登录,跳转到绑定页面
                  wx.setStorageSync('openid', res.data.returnObject)
                  wx.redirectTo({
                    url: '../register/register?type=0'
                  })
                } else {

                }
              },
              fail: function(err) {
                console.log(err)
              }
            })
          } else {
            console.log('获取用户登录态失败！' + res.errMsg)
          }
        }
      })
    // }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var user = wx.getStorageSync('terryUser')
    if (user) {
      this.setData({
        userName: user.name,
        userTeleno: user.teleno,
        userAvater: util.download(user.avatar)
      });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})