// pages/family/family.js
import req from '../../utils/service.js'
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: '0', //0: 查看家庭成员 1:选择家庭成员
    scrollTop: 0,
    scroll_height: 0,
    selectMember: {},
    memberListLi: [],
    hidden: true
  },
  getFamilyList: function() {
    var that = this
    req.getRequest('customerFamilys/list', {}).then(res => {
      if (res === 'loginSuccess') {
        that.getFamilyList()
        return
      }
      if (res.data.returnObject.length > 0) {
        for (var i in res.data.returnObject) {
          res.data.returnObject[i].selected = false
        }
      }
      that.setData({
        memberListLi: res.data.returnObject,
        hidden: res.data.returnObject.length == 0 ? false : true
      })
    })
  },
  chooseMember: function(e) {
    var tempArray = this.data.memberListLi
    for (var index in this.data.memberListLi) {
      if (tempArray[index].selected) {
        tempArray[index].selected = false
      }
    }
    var itemIndex = e.currentTarget.dataset.itemIndex
    var item = this.data.memberListLi[itemIndex]
    item.selected = !item.selected
    tempArray.splice(itemIndex, 1, item);
    this.setData({
      memberListLi: tempArray
    })
    this.setData({
      selectMember: item
    })
  },
  addMember: function() {
    wx.navigateTo({
      url: '../register/register?type=1',
    })
  },
  deleteMember: function(e) {
    var that = this
    var member = e.currentTarget.dataset.memberItem
    var patientId = member.id
    wx.showModal({
      title: '是否删除家庭成员！',
      success: function(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          req.deleteRequest('customerFamilys/' + patientId).then(res => {
            if (res === 'loginSuccess') {
              that.deleteMember(e)
              return
            }
            that.getFamilyList()
            wx.showToast({
              title: '删除成功！',
              icon: 'none',
              duration: 2000
            })
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  done: function() {
    var pages = getCurrentPages(); //  获取页面栈
    var currPage = pages[pages.length - 1]; // 当前页面
    var prevPage = pages[pages.length - 2]; // 上一个页面
    prevPage.setData({
      selectMember: this.data.selectMember
    })
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.setData({
      type: options.type //options为页面路由过程中传递的参数
    })
    if (this.data.type == 1) {
      that.setData({
        title: '选择家庭成员'
      })
    } else {
      that.setData({
        title: '家庭成员'
      })
    }
    wx.setNavigationBarTitle({
      title: that.data.title,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    var windowHeight = app.globalData.windowHeight;
    var windowWidth = app.globalData.windowWidth
    this.setData({
      scroll_height: windowHeight - windowWidth / 750 * 100,
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getFamilyList()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    wx.showNavigationBarLoading();
    console.log('111')
    wx.hideNavigationBarLoading();
    // 停止下拉动作
    wx.stopPullDownRefresh();

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})