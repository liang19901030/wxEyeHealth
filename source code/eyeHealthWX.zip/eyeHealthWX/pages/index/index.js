//index.js
import req from '../../utils/service.js'
import config from '../../utils/config.js'

//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../register/register'
    })
  },
  onLoad: function() {
    wx.login({
      success: function(res) {
        if (res.code) {
          console.log('获取用户登录成功！' + res.code)
          //发起网络请求
          // req.postRequest('basic/patients/loginByMiniProgram', {
          //   code: res.code
          // }).then(res => {
          //   console.log(res)
          // })
          wx.request({
            url: config.server.api + 'basic/patients/loginByMiniProgram',
            method: 'POST',
            header: {
              'content-type': 'application/x-www-form-urlencoded'
            },
            data: {
              code: res.code
            },
            success: function(res) {
              if (res.data.responseCode == 0) {
                wx.setStorageSync('terryUser', res.data.returnObject)
                wx.navigateTo({
                  url: '../home/home'
                })
              } else if (res.data.responseCode == 28) {
                wx.setStorageSync('openid', res.data.returnObject)
                wx.navigateTo({
                  url: '../register/register?type=0'
                })
              } else {

              }
            },
            fail: function(err) {
              console.log(err)
            }
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    });
    // if (app.globalData.userInfo) {
    //   this.setData({
    //     userInfo: app.globalData.userInfo,
    //     hasUserInfo: true
    //   })
    // } else if (this.data.canIUse){
    //   // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //   // 所以此处加入 callback 以防止这种情况
    //   app.userInfoReadyCallback = res => {
    //     this.setData({
    //       userInfo: res.userInfo,
    //       hasUserInfo: true
    //     })
    //   }
    // } else {
    //   // 在没有 open-type=getUserInfo 版本的兼容处理
    //   wx.getUserInfo({
    //     success: res => {
    //       app.globalData.userInfo = res.userInfo
    //       this.setData({
    //         userInfo: res.userInfo,
    //         hasUserInfo: true
    //       })
    //     }
    //   })
    // }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})