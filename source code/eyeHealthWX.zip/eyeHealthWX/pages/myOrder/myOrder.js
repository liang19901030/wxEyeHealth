// pages/myOrder/myOrder.js
import util from '../../utils/util.js'
import req from '../../utils/service.js'
import format from '../../utils/format.js'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scrollTop: 0,
    winWidth: 0,
    winHeight: 0,
    currentTab: 0,
    page: 0,
    historyPage: 0,
    scrollTop: 0,
    swiper_height: 0,
    right_width: 0,
    currentListLi: [],
    historyListLi: [],
    done: false,
    historyDone: false,
    hidden: true,
    noneMyOrderShow: false,
    noneHistoryShow: false,
    currentDate: ''
  },
  /**
   *  滑动切换tab
   */
  bindChange: function(e) {
    var that = this;
    that.goTop()
    that.setData({
      currentTab: e.detail.current
    })
    if (e.detail.current === 0) {
      that.setData({
        page: 0
      })
      that.getMyOrder(0)
    } else {
      that.setData({
        historyPage: 0
      })
      that.getHistoryOrder(0)
    }
  },
  /**
   *  点击切换tab
   */
  switchNav: function(e) {
    var that = this;
    if (that.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.goTop()
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  goTop: function() {
    this.setData({
      scrollTop: 0,
    })
  },
  getServerTime: function() {
    var that = this
    req.getRequest('times', {}).then(res => {
      if (res === 'loginSuccess') {
        that.getServerTime()
        return
      }
      var timestamp = res.data.returnObject
      var currentDate = format.formatTimestamp(timestamp)
      that.setData({
        currentDate: currentDate
      })
      var page = this.data.page;
      that.getMyOrder(page)
    })
  },
  getMyOrder: function(page) {
    var that = this
    req.getRequest('registeres/visitOrders/byPatient', {
      isAll: 0,
      pgIndex: page,
      pgCnt: '10',
    }).then(res => {
      that.setData({
        hidden: true
      })
      if (res === 'loginSuccess') {
        that.getMyOrder(0)
        return
      }
      if (res.data.returnObject.length > 0) {
        for (var i in res.data.returnObject) {
          res.data.returnObject[i].doctorAvatar = util.download(res.data.returnObject[i].doctorAvatar)
          res.data.returnObject[i].doctorTitle = res.data.returnObject[i].doctorTitle != null ? res.data.returnObject[i].doctorTitle : ''
          var visitDate = res.data.returnObject[i].visitDate
          var restDays = format.DateDiff(that.data.currentDate, visitDate)
          res.data.returnObject[i].restDays = restDays
        }
      }
      if (page === 0) {
        that.setData({
          page: page + 1,
          currentListLi: res.data.returnObject,
          done: false,
          noneMyOrderShow: res.data.returnObject == 0 ? true : false
        })
        if (res.data.returnObject.length < 10) {
          that.setData({
            done: true
          })
        }
      } else {
        if (res.data.returnObject.length < 10) {
          that.setData({
            page: page + 1,
            currentListLi: that.data.currentListLi.concat(res.data.returnObject),
            done: true
          })
        } else {
          that.setData({
            page: page + 1,
            currentListLi: that.data.currentListLi.concat(res.data.returnObject)
          })
        }
      }
    })
  },
  getHistoryOrder: function(page) {
    var that = this
    req.getRequest('registeres/visitOrders/byPatient', {
      isAll: 1,
      pgIndex: page,
      pgCnt: '10',
    }).then(res => {
      that.setData({
        hidden: true
      })
      if (res === 'loginSuccess') {
        that.getHistoryOrder(0)
        return
      }
      if (res.data.returnObject.length > 0) {
        for (var i in res.data.returnObject) {
          res.data.returnObject[i].doctorAvatar = util.download(res.data.returnObject[i].doctorAvatar)
          res.data.returnObject[i].doctorTitle = res.data.returnObject[i].doctorTitle != null ? res.data.returnObject[i].doctorTitle : ''
          res.data.returnObject[i].status = util.formatOrderStatus(res.data.returnObject[i].status)
        }
      }
      if (page === 0) {
        that.setData({
          historyPage: page + 1,
          historyListLi: res.data.returnObject,
          historyDone: false,
          noneHistoryShow: res.data.returnObject.length == 0 ? true : false
        })
        if (res.data.returnObject.length < 10) {
          that.setData({
            historyDone: true
          })
        }
      } else {
        if (res.data.returnObject.length < 10) {
          that.setData({
            historyPage: page + 1,
            historyListLi: that.data.historyListLi.concat(res.data.returnObject),
            historyDone: true
          })
        } else {
          that.setData({
            historyPage: page + 1,
            historyListLi: that.data.historyListLi.concat(res.data.returnObject),
            historyDone: false
          })
        }
      }
    })
  },
  loadMore: function() {
    var done = this.data.done;
    if (done) {
      return
    } else {
      wx.showToast({
        title: '加载中',
        icon: 'loading',
        duration: 500
      });
      var page = this.data.page;
      this.getMyOrder(page)
    }
  },
  upper: function() {
    console.log('下拉')
    if (this.data.currentTab == 0) {
      this.setData({
        hidden: false,
        page: 0
      })
      this.getMyOrder(0)
    } else {
      this.setData({
        hidden: false,
        historyPage: 0
      })
      this.getHistoryOrder(0)
    }
  },

  lower: function() {
    console.log('上拉')
    if (this.data.currentTab == 0) {
      if (this.data.done) {
        return
      }
      this.setData({
        hidden: false,
      })
      this.getMyOrder(this.data.page)
    } else {
      if (this.data.historyDone) {
        return
      }
      this.setData({
        hidden: false,
      })
      this.getHistoryOrder(this.data.historyPage)
    }
  },

  myOrder: function() {
    wx.navigateTo({
      url: '../order/order',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.getServerTime()
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight,
          swiper_height: res.windowHeight - res.windowWidth / 750 * 90,
          right_width: res.windowWidth - res.windowWidth / 750 * 185
        })
      },
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    // if (this.data.currentTab == 0) {
    //   this.setData({
    //     hidden: true,
    //     page: 0
    //   })
    //   this.getMyOrder(0)
    // } else {
    //   this.setData({
    //     hidden: true,
    //     historyPage: 0
    //   })
    //   this.getHistoryOrder(0)
    // }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    // if (this.data.currentTab == 0) {
    //   if (this.data.done) {
    //     return
    //   }
    //   this.setData({
    //     hidden: false,
    //   })
    //   this.getMyOrder(this.data.page)
    // } else {
    //   if (this.data.historyDone) {
    //     return
    //   }
    //   this.setData({
    //     hidden: false,
    //   })
    //   this.getHistoryOrder(this.data.historyPage)
    // }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})