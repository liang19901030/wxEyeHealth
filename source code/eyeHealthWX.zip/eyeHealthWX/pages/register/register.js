// pages/register/register.js
import req from '../../utils/service.js'
import config from '../../utils/config.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: '',
    openid: '',
    title: '',
    userName: '', // 用户姓名
    userTeleno: '', // 用户手机号
    userIdNumber: '', //用户身份证号
    code: '', // 验证码
    time: 0, // 验证码计时
    isCodeError: false, // 验证码错误
    isPhoneError: false, // 手机格式错误
    showErrorTip: false,
    focusName: true,
    focusIdNumber: false,
    focusTeleno: false,
    focusCode: false,
    errorTip: ''
  },
  setName: function(e) {
    var val = e.detail.value;
    this.setData({
      userName: val
    });

  },
  setIdNumber: function(e) {
    var val = e.detail.value;
    this.setData({
      userIdNumber: val
    });

  },
  setTeleno: function(e) {
    var val = e.detail.value;
    this.setData({
      userTeleno: val
    });

  },
  setCode: function(e) {
    var val = e.detail.value;
    this.setData({
      code: val
    });

  },
  focus: function(e) {
    if (e.target.id == 'name') {
      this.setData({
        focusName: true,
        focusIdNumber: false,
        focusTeleno: false,
        focusCode: false
      })
    } else if (e.target.id == 'idNumber') {
      this.setData({
        focusName: false,
        focusIdNumber: true,
        focusTeleno: false,
        focusCode: false
      })
    } else if (e.target.id == 'teleno') {
      this.setData({
        focusName: false,
        focusIdNumber: false,
        focusTeleno: true,
        focusCode: false
      })
    } else {
      this.setData({
        focusName: false,
        focusIdNumber: false,
        focusTeleno: false,
        focusCode: true
      })
    }
  },
  /**
   *  获取验证码 
   */
  sendCode: function() {
    if (this.data.time > 0) {
      return
    }
    var teleReg = /^1(3|4|5|7|8)\d{9}$/
    if (!teleReg.test(this.data.userTeleno)) {
      this.isPhoneError = true
      wx.showToast({
        title: '请填写正确的手机号',
        icon: 'none',
        duration: 2000
      })
    } else {
      this.isPhoneError = false
      req.postRequest('sms/code/' + this.data.userTeleno).then(res => {
        this.setData({
          time: 60
        })
        this.timeInteval()
      })
    }
  },
  /* 倒计时 */
  timeInteval: function() {
    this.setData({
      time: this.data.time - 1
    })
    var _this = this
    if (this.data.time > 0) {
      setTimeout(function() {
        _this.timeInteval()
      }, 1000)
    }
  },
  validateTeleno: function() {
    var teleReg = /^1(3|4|5|7|8)\d{9}$/;
    if (!teleReg.test(this.data.userTeleno)) {
      return false
    }
    return true
  },
  validateIdNumber: function() {
    var idNumberReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
    if (!idNumberReg.test(this.data.userIdNumber)) {
      return false
    }
    return true
  },

  validateForm: function() {
    if (!this.data.userName) {
      wx.showToast({
        title: '请填写您的姓名',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    if (!this.validateIdNumber()) {
      wx.showToast({
        title: '请填写正确的身份证号',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    if (!this.validateTeleno()) {
      wx.showToast({
        title: '请填写正确的手机号',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    if (!this.data.code) {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none',
        duration: 2000
      })
      return;
    }
    if (this.data.type == 0) {
      var openid = wx.getStorageSync('openid')
      req.putRequest('patients/bindMiniProgram', {
        name: this.data.userName,
        openId: openid,
        idCard: this.data.userIdNumber,
        teleno: this.data.userTeleno,
        code: this.data.code
      }).then(res => {
        var user = res.data.returnObject;
        wx.setStorageSync('terryUser', user)
        wx.redirectTo({
          url: '../home/home',
        })
      })
    } else {
      var user = wx.getStorageSync('terryUser')
      var patientId = user.id
      req.postRequest('customerFamilys', {
        name: this.data.userName,
        patientId: patientId,
        idCard: this.data.userIdNumber,
        teleno: this.data.userTeleno,
        code: this.data.code
      }).then(res => {
        wx.navigateBack({
          delta: 1
        })
      })
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.setData({
      type: options.type, //options为页面路由过程中传递的参数
    })
    if (this.data.type == 1) {
      that.setData({
        title: '添加'
      })
    } else {
      that.setData({
        title: '身份绑定'
      })
    }
    wx.setNavigationBarTitle({
      title: that.data.title,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})