// pages/report/report.js
import util from '../../utils/util.js'
import req from '../../utils/service.js'
import format from '../../utils/format.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    reportList: [],
    page: 0,
    done: false,
    hidden: true,
    noneShow: false,
    containerHeight: ''
  },
  getReportList: function(page) {
    var that = this
    req.getRequest('eye/reports/patient/list', {
      pgIndex: page,
      pgCnt: '10',
    }).then(res => {
      if (res === 'loginSuccess') {
        that.getReportList(0)
        return
      }
      if (res.data.returnObject.list.length > 0) {
        for (var i in res.data.returnObject.list) {
          res.data.returnObject.list[i].reportCover = util.download(res.data.returnObject.list[i].reportCover)
          res.data.returnObject.list[i].reportType = util.formatReportType(res.data.returnObject.list[i].reportType)
          res.data.returnObject.list[i].reportDate = format.formatDate(res.data.returnObject.list[i].reportDate)

        }
      }
      if (page == 0) {
        that.setData({
          page: page + 1,
          reportList: res.data.returnObject.list,
          done: false,
          noneShow: res.data.returnObject.list.length == 0 ? true : false
        })
      } else {
        if (res.data.returnObject.list.length < 10) {
          that.setData({
            page: page + 1,
            reportList: that.data.reportList.concat(res.data.returnObject.list),
            done: true
          })
        } else {
          that.setData({
            page: page + 1,
            reportList: that.data.reportList.concat(res.data.returnObject.list)
          })
        }
      }
      wx.stopPullDownRefresh()
      wx.hideNavigationBarLoading()
      that.setData({
        hidden: true,
      })
    })
  },
  chooseReport: function(e) {
    var report = e.currentTarget.dataset.reportItem
    wx.navigateTo({
      url: '../viewReport/viewReport?shareId=' + report.shareId,
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    that.getReportList(0)
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          containerHeight: res.windowHeight,
        })
      },
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    wx.showNavigationBarLoading();
    this.getReportList(0)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if(this.data.done){
      return
    }
    this.setData({
      hidden: false,
    })
    this.getReportList(this.data.page)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})