// pages/orderPay/orderPay.js
import util from '../../utils/util.js'
import req from '../../utils/service.js'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    scroll_height: 0,
    selectedDateDic: {},
    doctorAvatar: '',
    doctorId: '',
    doctorName: '',
    doctorTitle:'',
    hospitalName: '',
    departmentName: '',
    selectedMemberId: '',
    prepayId: ''
  },
  pad2: function(n) {
    return n < 10 ? '0' + n : n
  },

  generateTimeReqestNumber: function() {
    var date = new Date()
    return date.getFullYear().toString() + pad2(date.getMonth() + 1) + pad2(date.getDate()) + pad2(date.getHours()) + pad2(date.getMinutes())
  },
  createBookingNo: function() {
    var rand = Math.floor(Math.random() * 900) + 100
    var order_id = generateTimeReqestNumber() + rand
    return order_id
  },
  createNonceStr: function() {
    return Math.random().toString(36).substr(2, 15)
  },

  // 时间戳产生的函数：
  createTimeStamp: function() {
    return parseInt(new Date().getTime() / 1000) + ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.setData({
      doctorId: options.doctorId,
      doctorName: options.doctorName,
      doctorTitle: options.doctorTitle,
      hospitalName: options.hospitalName,
      departmentName: options.departmentName,
      doctorAvatar: util.download(options.doctorAvatar), // options为页面路由过程中传递的参数
      selectedDateDic: JSON.parse(options.selectedDateDic),
      selectedMemberId: options.selectedMemberId,
    })
    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight,
          scroll_height: res.windowHeight - res.windowWidth / 750 * 390
        })
      },
    });
  },
  /**
   * 支付--拉起微信支付
   */
  pay: function() {
    wx.showLoading({
      title: '',
      mask: true
    })
    var that = this
    req.postRequest('registeres/byPatient', {
      customerFamilyId: that.data.selectedMemberId,
      doctorId: that.data.doctorId,
      visitDate: that.data.selectedDateDic.visitDate,
      timeInterval: that.data.selectedDateDic.timeInterval
    }).then(res => {
      wx.hideLoading()
      if (res === 'loginSuccess') {
        that.pay()
        return
      }
      that.setData({
        prepayId: res.data.returnObject.prepayId
      })
      wx.requestPayment({
        'timeStamp': res.data.returnObject.timeStamp,
        'nonceStr': res.data.returnObject.nonceStr,
        'package': 'prepay_id=' + res.data.returnObject.prepayId,
        'signType': res.data.returnObject.signType,
        'paySign': res.data.returnObject.paySign,
        'success': function(res) {
          console.log('success:' + JSON.stringify(res));
          that.payFlows(1, res.errMsg)
        },
        'fail': function(res) {
          console.log('fail:' + JSON.stringify(res));
          that.payFlows(2, res.errMsg)
        }
      })
    })
  },
  payFlows: function(status, remark) {
    var that = this
    req.postRequest('accounts', {
      prepayId: that.data.prepayId,
      status: status,
      remark: remark,
    }).then(res => {
      if (status == 1) {
        wx.navigateTo({
          url: '../paySuccess/paySuccess',
        })
      } else {
        wx.showToast({
          title: '支付失败！',
          icon: 'none',
          duration: 500
        });
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})