// pages/info/info.js
import util from '../../utils/util.js'
import MD5 from '../../lib/md5.js'
import config from '../../utils/config.js'
import Base64 from '../../lib/Base64.js'
import Crypto from '../../lib/crypto.js'
require('../../lib/hmac.js');
require('../../lib/sha1.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userAvater: '', // 头像
    userName: '', // 用户姓名
    userTeleno: '', // 用户手机号
    userIdNumber: '', //用户身份证号
    age: '',
    sex: '',
    uploadTime: ''
  },
  chooseImage: function() {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function(res) {
        that.setData({
          userAvater: res.tempFilePaths
        })
        that.upload(res.tempFiles[0])
      },
    })
  },
  /*执行上传*/
  // upload: function(file) {
  //   if (file.size > 0) {
  //     this.applyTokenDo(file)
  //   }
  // },
  // /*上传文件*/
  // uploadFile: function(client, file) {
  //   if (file == undefined) {
  //     return;
  //   }
  //   var _this = this;

  //   _this.uploadTime = _this.uploadTime.split('T')[0];
  //   //文件名后缀
  //   var fileSuffix = file.path.substring(file.path.lastIndexOf('.') + 1, file.path.length);
  //   file.fileSuffix = fileSuffix.toLowerCase();
  //   //支持上传的文件类型
  //   var fileType = "jpg,jpeg,png";
  //   if (fileType.indexOf(file.fileSuffix) == -1) {
  //     pop("您只能上传" + fileType + "格式文件");
  //     return;
  //   }
  //   var fileName = file.path;
  //   var str = fileName + new Date().getTime();
  //   var md5Value = MD5.hexMD5(str)
  //   file.key = 'avatar/' + _this.uploadTime + '/' + md5Value + '.' + fileSuffix;
  //   client.key = file.key
  //   const policyBase64 = _this.getPolicyBase64()
  //   const signature = _this.getSignature(policyBase64, client.accessKeySecret)
  //   wx.uploadFile({
  //     url: 'https://oss-cn-hangzhou.aliyuncs.com',
  //     filePath: file.path,
  //     name: 'file',
  //     formData: {
  //       'key': file.key,
  //       'policy': policyBase64,
  //       'OSSAccessKeyId': client.accessKeyId,
  //       'signature': signature,
  //       'success_action_status': '200',
  //       'bucket': client.bucket,
  //       'stsToken': client.stsToken
  //     },
  //     success: function(res) {
  //       var data = res.data
  //       //do something
  //     }
  //   })

  //   // co(function*() {
  //   //   //分片上传
  //   //   var result = yield client.multipartUpload(file.key, file);
  //   // }).then(function() {
  //   //   var avataPath = file.key
  //   //   _this.updateAvatar(avataPath)
  //   // }).catch(function(err) {
  //   //   wx.showToast({
  //   //     title: '上传失败，请重新选择图片上传',
  //   //     icon: 'none',
  //   //     duration: 2000
  //   //   })
  //   // });
  // },
  // applyTokenDo: function(file) {
  //   var that = this
  //   var user = wx.getStorageSync('terryUser')
  //   var client = ''
  //   wx.request({
  //     url: config.server.api + 'basic/securitytokens',
  //     method: 'POST',
  //     header: {
  //       'content-type': 'application/x-www-form-urlencoded',
  //       'userId': user.id,
  //       'token': user.accessToken,
  //       'clientType': 15,
  //       'userType': 1
  //     },
  //     success: function(result) {
  //       if (result.responseCode == 26) {
  //         wx.showToast({
  //           title: '登录失效',
  //           icon: 'none',
  //           duration: 2000
  //         })
  //         return
  //       }
  //       if (result.responseCode == 24) {
  //         wx.showToast({
  //           title: '当前操作没有权限',
  //           icon: 'none',
  //           duration: 2000
  //         })
  //         return
  //       }

  //       var creds = result.data.returnObject;
  //       if (creds == undefined) {
  //         wx.showToast({
  //           title: '获取上传秘钥失败，请重新上传',
  //           icon: 'none',
  //           duration: 2000
  //         })
  //         return
  //       }
  //       //上传时间
  //       that.uploadTime = creds.expiration;
  //       client = {
  //         region: config.server.region,
  //         secure: true, //是否使用https访问
  //         accessKeyId: creds.accessKeyId,
  //         accessKeySecret: creds.accessKeySecret,
  //         stsToken: creds.securityToken,
  //         bucket: config.server.ossBucket
  //       }
  //       console.log('成功生成oss实例')
  //       that.uploadFile(client, file)
  //     },
  //     fail: function(err) {
  //       console.log(err)
  //     }
  //   })
  // },

  // getPolicyBase64: function() {
  //   let date = new Date();
  //   date.setHours(date.getHours() + 87600);
  //   let srcT = date.toISOString();
  //   const policyText = {
  //     "expiration": srcT, //设置该Policy的失效时间
  //     "conditions": [
  //       ["content-length-range", 0, 5 * 1024 * 1024] // 设置上传文件的大小限制,5mb
  //     ]
  //   };

  //   const policyBase64 = Base64.encode(JSON.stringify(policyText));
  //   return policyBase64;
  // },

  // getSignature: function (policyBase64, accessKeySecret) {
  //   const accesskey = accessKeySecret;

  //   const bytes = Crypto.HMAC(Crypto.SHA1, policyBase64, accesskey, {
  //     asBytes: true
  //   });
  //   const signature = Crypto.util.bytesToBase64(bytes);

  //   return signature;
  // },

  editName: function() {
    wx.navigateTo({
      url: '../edit/edit?type=0&name=' + this.data.userName
    })
  },
  editIdNumber: function() {
    wx.navigateTo({
      url: '../edit/edit?type=1&IdNumber=' + this.data.userIdNumber
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var user = wx.getStorageSync('terryUser')
    this.setData({
      userName: user.name,
      userTeleno: user.teleno,
      userIdNumber: user.idCard,
      userAvater: util.download(user.avatar),
      age: user.age,
      sex: user.sex == 0 ? '男' : '女'
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})